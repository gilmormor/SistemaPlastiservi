$(document).ready(function () {
    $( "#nombre" ).focus();
});