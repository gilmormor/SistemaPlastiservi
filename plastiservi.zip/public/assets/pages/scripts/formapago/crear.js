$(document).ready(function () {
    Biblioteca.validacionGeneral('form-general');
    $("#descripcion").focus();
});
